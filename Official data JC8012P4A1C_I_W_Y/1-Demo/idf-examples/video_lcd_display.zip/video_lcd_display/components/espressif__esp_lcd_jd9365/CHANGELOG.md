# ChangeLog

## v1.0.2 - 2025-01-13

### bugfix:

* Fixed the issue with macro inclusion

## v1.0.1 - 2024-11-10

### bugfix:

* Modified the order of reading the ID register

## v1.0.0 - 2024-08-12

### Enhancements:

* Component version maintenance, code improvement, and documentation enhancement

## v0.1.0 - 2024-05-07

### Enhancements:

* Implement the driver for the JD9365 MIPI-DSI LCD controller
